// ============================================================
// FILE: lib/main.dart   (REPLACE EXISTING)
// Added: DeepLinkHandler.init() + processPendingLink()
// ============================================================

import 'package:QuizSphere/login/login_screen.dart';
import 'package:QuizSphere/quizes/admin/screens/admin_daily_quiz_screen.dart';
import 'package:QuizSphere/quizes/home/onboarding_screen.dart';
import 'package:flutter/foundation.dart' show kIsWeb;
import 'package:flutter/material.dart';
import 'package:firebase_core/firebase_core.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:flutter_dotenv/flutter_dotenv.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';

import 'firebase_options.dart';
import 'core/services/fcm_service.dart';
import 'features/deep_links/deep_link_handler.dart'; // ← NEW

final GlobalKey<NavigatorState> navigatorKey = GlobalKey<NavigatorState>();

Future<void> main() async {
  WidgetsFlutterBinding.ensureInitialized();

  // ── .env ─────────────────────────────────────────────────────────────────
  try {
    await dotenv.load(fileName: '.env');
  } catch (e) {
    debugPrint('[dotenv] Failed to load .env: $e');
  }

  // ── Firebase ──────────────────────────────────────────────────────────────
  try {
    await Firebase.initializeApp(
      options: DefaultFirebaseOptions.currentPlatform,
    );
  } catch (e) {
    debugPrint('[Firebase] initializeApp failed: $e');
  }

  // ── FCM ───────────────────────────────────────────────────────────────────
  if (!kIsWeb) {
    await FcmService.init().catchError((e) {
      debugPrint('[FCM] init skipped: $e');
      return null;
    });
  }

  // ── Deep links (cold-start capture) ──────────────────────────────────────
  if (!kIsWeb) {
    await DeepLinkHandler.init(); // ← NEW
  }

  runApp(const ProviderScope(child: QuizApp()));
}

class QuizApp extends StatelessWidget {
  const QuizApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      // Use DeepLinkHandler.navigatorKey so links can navigate from anywhere
      navigatorKey:
          DeepLinkHandler.navigatorKey, // ← CHANGED from local navigatorKey
      debugShowCheckedModeBanner: false,
      title: 'QuizAura',
      theme: ThemeData(
        useMaterial3: true,
        colorSchemeSeed: Colors.teal,
        pageTransitionsTheme: const PageTransitionsTheme(
          builders: {
            TargetPlatform.android: CupertinoPageTransitionsBuilder(),
            TargetPlatform.iOS: CupertinoPageTransitionsBuilder(),
          },
        ),
        appBarTheme: const AppBarTheme(
          color: Colors.teal,
          centerTitle: true,
          elevation: 0,
        ),
        elevatedButtonTheme: ElevatedButtonThemeData(
          style: ElevatedButton.styleFrom(
            minimumSize: const Size(double.infinity, 50),
            shape: RoundedRectangleBorder(
              borderRadius: BorderRadius.circular(12),
            ),
          ),
        ),
      ),
      home: const AuthWrapper(),
    );
  }
}

class AuthWrapper extends StatelessWidget {
  const AuthWrapper({super.key});

  @override
  Widget build(BuildContext context) {
    return StreamBuilder<User?>(
      stream: FirebaseAuth.instance.authStateChanges(),
      builder: (context, snapshot) {
        if (snapshot.connectionState == ConnectionState.waiting) {
          return const _SplashScreen();
        }

        if (snapshot.hasError) {
          return const Scaffold(
            backgroundColor: Color(0xFF0F2027),
            body: Center(
              child: Text(
                'Authentication error.\nPlease restart the app.',
                textAlign: TextAlign.center,
                style: TextStyle(color: Colors.white70),
              ),
            ),
          );
        }

        if (!snapshot.hasData) {
          return const LoginScreen();
        }

        final user = snapshot.data!;

        if (user.email == 'admin741@gmail.com') {
          return const AdminDailyQuizManagerScreen();
        }

        if (!kIsWeb) {
          FcmService.saveTokenForUser(user.uid);
          // Process any deep link that arrived before/during login
          DeepLinkHandler.processPendingLink(); // ← NEW (fire-and-forget)
        }

        return const HomeScreen();
      },
    );
  }
}

// ── Branded splash screen ──────────────────────────────────────────────────────
class _SplashScreen extends StatelessWidget {
  const _SplashScreen();

  @override
  Widget build(BuildContext context) {
    return const Scaffold(
      backgroundColor: Color(0xFF0F2027),
      body: Center(
        child: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            Icon(Icons.quiz_rounded, size: 72, color: Colors.tealAccent),
            SizedBox(height: 24),
            Text(
              'QuizAura',
              style: TextStyle(
                color: Colors.white,
                fontSize: 28,
                fontWeight: FontWeight.bold,
                letterSpacing: 1.5,
              ),
            ),
            SizedBox(height: 32),
            SizedBox(
              width: 24,
              height: 24,
              child: CircularProgressIndicator(
                color: Colors.tealAccent,
                strokeWidth: 2.5,
              ),
            ),
          ],
        ),
      ),
    );
  }
}
