import 'dart:convert';
import 'dart:io';
import 'package:http/http.dart' as http;

class BackendService {
  static const String _pistonUrl =
      'https://emkc.org/api/v2/piston/execute';

  static Future<Map<String, dynamic>> runCode({
    required String quizId,
    required String questionId,
    required String code,
    required String language,
    required String version,
    String stdin = '',
  }) async {
    try {
      final normalizedLang = _normalizeLanguage(language);
      final fileName = _fileName(language);

      final response = await http
          .post(
            Uri.parse(_pistonUrl),
            headers: const {'Content-Type': 'application/json'},
            body: jsonEncode({
              'language': normalizedLang,
              'version': version,
              'files': [
                {
                  'name': fileName,
                  'content': code,
                }
              ],
              'stdin': stdin,
              'args': [],
              'compile_timeout': 15000,
              'run_timeout': 10000,
              'compile_memory_limit': -1,
              'run_memory_limit': -1,
            }),
          )
          .timeout(const Duration(seconds: 20));

      if (response.statusCode != 200) {
        throw Exception(
          'Piston error ${response.statusCode}: ${response.body}',
        );
      }

      final Map<String, dynamic> data = jsonDecode(response.body);

      // Safely extract all output fields
      final runBlock    = data['run']     as Map<String, dynamic>?;
      final compileBlock = data['compile'] as Map<String, dynamic>?;

      final stdout       = runBlock?['stdout']?.toString()     ?? '';
      final stderr       = runBlock?['stderr']?.toString()     ?? '';
      final compileErr   = compileBlock?['stderr']?.toString() ?? '';
      final compileOut   = compileBlock?['output']?.toString() ?? '';
      final exitCode     = runBlock?['code'];

      return {
        'stdout':         stdout,
        'stderr':         stderr,
        'compile_output': compileErr.isNotEmpty ? compileErr : compileOut,
        'exitCode':       exitCode,
      };
    } on SocketException {
      throw Exception('No internet connection. Check your network and try again.');
    } on FormatException {
      throw Exception('Invalid response from the execution server.');
    } on http.ClientException catch (e) {
      throw Exception('Network error: ${e.message}');
    } catch (e) {
      rethrow;
    }
  }

  // ─── Normalize Piston language keys ───────────────────────────────────────
  static String _normalizeLanguage(String language) {
    switch (language.toLowerCase().trim()) {
      case 'python':
      case 'py':
        return 'python3';
      case 'python3':
        return 'python3';
      case 'c':
        return 'c';
      case 'cpp':
      case 'c++':
        return 'cpp';
      case 'javascript':
      case 'js':
        return 'javascript';
      case 'java':
        return 'java';
      default:
        return language.toLowerCase().trim();
    }
  }

  // ─── Correct source-file names per language ───────────────────────────────
  static String _fileName(String language) {
    switch (language.toLowerCase().trim()) {
      case 'c':
        return 'main.c';
      case 'cpp':
      case 'c++':
        return 'main.cpp';
      case 'java':
        return 'Main.java';
      case 'python':
      case 'python3':
      case 'py':
        return 'main.py';
      case 'javascript':
      case 'js':
        return 'main.js';
      default:
        return 'main';
    }
  }
}
