import 'dart:convert';
import 'package:http/http.dart' as http;
import 'package:flutter_dotenv/flutter_dotenv.dart';

import 'package:QuizSphere/core/services/ai_quiz_access_service.dart';

class GroqAIService {
  static const String _endpoint =
      "https://api.groq.com/openai/v1/chat/completions";

  final String _apiKey;

  // FIX 1: Strip surrounding quotes AND whitespace from the key.
  // If .env has:  Quiz_API="gsk_xxx"  or  Quiz_API='gsk_xxx'
  // dotenv returns the value WITH the quotes → causes 401 Invalid API Key.
  GroqAIService()
    : _apiKey = _sanitizeKey(
        dotenv.maybeGet('Quiz_API') ?? dotenv.env['Quiz_API'] ?? '',
      );

  static String _sanitizeKey(String raw) =>
      raw.trim().replaceAll('"', '').replaceAll("'", '');

  bool get isConfigured => _apiKey.isNotEmpty;

  Future<List<Map<String, dynamic>>> generateMCQs({
    required String topic,
    required String difficulty,
    int count = 5,
  }) async {
    // AI Quiz Generation is mobile-only. Every known UI entry point already
    // stops before reaching this call on web — this check is a final
    // backstop so the actual Groq network call can never run on web, no
    // matter which code path gets here.
    if (AiQuizAccessService.isBlockedOnWeb) {
      throw Exception(AiQuizAccessService.blockedMessage);
    }

    if (_apiKey.isEmpty) {
      throw Exception(
        'AI API key (Quiz_API) is not configured.\n'
        'Add it to your .env file and ensure it is listed in pubspec.yaml assets.',
      );
    }

    // FIX 2: max_tokens must scale with question count, otherwise Groq
    // truncates the JSON mid-object for larger counts (e.g. 15 hard MCQs
    // with solutions easily exceeds 2500 tokens) → jsonDecode fails.
    // ~180-220 tokens per MCQ (question + 4 options + solution) is a safe
    // estimate; we pad generously and clamp to the model's output ceiling.
    final int maxTokens = (count * 260 + 800).clamp(1500, 8000);

    try {
      final questions = await _requestMCQs(
        topic: topic,
        difficulty: difficulty,
        count: count,
        maxTokens: maxTokens,
      );
      return questions;
    } on Exception catch (e) {
      // FIX 3: one retry on parse/format failure — Groq occasionally emits
      // malformed JSON on the first pass for larger counts; a fresh attempt
      // (with the same generous token budget) usually succeeds.
      final msg = e.toString();
      final isRecoverable =
          msg.contains('JSON') ||
          msg.contains('Invalid') ||
          msg.contains('Empty response');
      if (!isRecoverable) rethrow;

      try {
        return await _requestMCQs(
          topic: topic,
          difficulty: difficulty,
          count: count,
          maxTokens: maxTokens,
        );
      } catch (_) {
        rethrow; // surface the original, clearer error
      }
    }
  }

  Future<List<Map<String, dynamic>>> _requestMCQs({
    required String topic,
    required String difficulty,
    required int count,
    required int maxTokens,
  }) async {
    final prompt =
        '''
Generate exactly $count UNIQUE multiple-choice questions on topic "$topic".
Difficulty: $difficulty.

Respond ONLY with a JSON object in this exact shape (no markdown, no text outside the JSON):
{
  "questions": [
    {
      "question": "string",
      "options": ["A","B","C","D"],
      "correctIndex": 0,
      "solution": "Short clear explanation why the correct answer is right"
    }
  ]
}

Rules:
- "questions" must contain exactly $count items.
- Exactly 4 options per question.
- correctIndex must be an integer between 0 and 3.
- Keep each "solution" concise (under 25 words) so the full response fits.
- Do not include any keys other than question, options, correctIndex, solution.
''';

    final response = await http
        .post(
          Uri.parse(_endpoint),
          headers: {
            "Authorization": "Bearer $_apiKey",
            "Content-Type": "application/json",
          },
          body: jsonEncode({
            "model": "openai/gpt-oss-20b",
            "messages": [
              {"role": "user", "content": prompt},
            ],
            "temperature": 0.3,
            "max_tokens": maxTokens,
            // FIX 4: force valid JSON output. Groq (OpenAI-compatible)
            // guarantees the response is a syntactically valid JSON object
            // when this is set, which eliminates the "stray text around
            // the array" / broken-bracket failures the old bare-array
            // approach was prone to.
            "response_format": {"type": "json_object"},
          }),
        )
        .timeout(const Duration(seconds: 45));

    if (response.statusCode == 401) {
      throw Exception(
        'Invalid API key. Check Quiz_API in your .env file.\n'
        'Tip: No quotes around the value. Example:\n  Quiz_API=gsk_yourKeyHere',
      );
    }
    if (response.statusCode == 429) {
      throw Exception(
        'Groq API rate limit reached. Please wait and try again.',
      );
    }
    if (response.statusCode != 200) {
      throw Exception(
        'Groq API error ${response.statusCode}: ${response.body}',
      );
    }

    final decoded = jsonDecode(response.body);
    final content = decoded['choices']?[0]?['message']?['content'];
    final finishReason = decoded['choices']?[0]?['finish_reason'];

    if (content is! String || content.trim().isEmpty) {
      throw Exception('Empty response from AI. Please try again.');
    }

    // FIX 5: if Groq itself reports the output was cut off for hitting the
    // token cap, fail fast with a clear message instead of trying (and
    // failing) to parse a half-written JSON object.
    if (finishReason == 'length') {
      throw Exception(
        'AI response was truncated (too many questions requested at once). '
        'Try generating fewer questions, or retry.',
      );
    }

    final cleanJson = _extractJsonObject(content);
    return _safeParseQuestions(cleanJson, count);
  }

  /// Extracts the outermost {...} object, tolerant of any stray text
  /// the model might still wrap around it despite response_format.
  String _extractJsonObject(String raw) {
    final start = raw.indexOf('{');
    final end = raw.lastIndexOf('}');
    if (start == -1 || end == -1 || end < start) {
      throw Exception("No valid JSON object found in AI response");
    }
    return raw.substring(start, end + 1);
  }

  List<Map<String, dynamic>> _safeParseQuestions(
    String raw,
    int expectedCount,
  ) {
    final parsed = jsonDecode(raw);

    // Accept either {"questions": [...]} (new format) or a bare [...]
    // (defensive fallback in case the model ever ignores response_format).
    final List rawList;
    if (parsed is Map<String, dynamic> && parsed['questions'] is List) {
      rawList = parsed['questions'] as List;
    } else if (parsed is List) {
      rawList = parsed;
    } else {
      throw Exception("Response JSON did not contain a questions array");
    }

    if (rawList.isEmpty) {
      throw Exception("AI returned zero questions. Please try again.");
    }

    final questions = rawList.map<Map<String, dynamic>>((q) {
      if (q is! Map<String, dynamic>) {
        throw Exception("Invalid question object");
      }

      final question = q['question'];
      final options = q['options'];
      final correctIndex = q['correctIndex'];
      final solution = q['solution'];

      if (question is! String || question.trim().isEmpty) {
        throw Exception("Invalid question text");
      }
      if (options is! List || options.length != 4) {
        throw Exception("Invalid options — need exactly 4");
      }
      if (correctIndex is! int || correctIndex < 0 || correctIndex > 3) {
        throw Exception("Invalid correctIndex");
      }
      if (solution is! String || solution.trim().length < 5) {
        throw Exception("Invalid solution text");
      }

      return {
        'question': question,
        'options': List<String>.from(options),
        'correctIndex': correctIndex,
        'solution': solution,
      };
    }).toList();

    return questions;
  }
}
