// ============================================================
// FILE: lib/ads/widgets/banner_ad_widget.dart
// FIXES:
//   1. Smooth AnimatedSwitcher fade-in when ad loads
//   2. Reads isPremiumProvider reactively — hides instantly on upgrade
//   3. Properly disposes ad to release native resources
//   4. Zero-height SizedBox.shrink() for premium users (no layout shift)
// ============================================================

import 'package:QuizSphere/ads/provider/premium_provider.dart';
import 'package:flutter/foundation.dart' show kIsWeb;
import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:google_mobile_ads/google_mobile_ads.dart';

import '../services/admob_service.dart';

class BannerAdWidget extends ConsumerStatefulWidget {
  const BannerAdWidget({super.key});

  @override
  ConsumerState<BannerAdWidget> createState() => _BannerAdWidgetState();
}

class _BannerAdWidgetState extends ConsumerState<BannerAdWidget> {
  BannerAd? _bannerAd;
  bool _adLoaded = false;

  @override
  void initState() {
    super.initState();
    WidgetsBinding.instance.addPostFrameCallback((_) => _loadAdIfNeeded());
  }

  void _loadAdIfNeeded() {
    if (kIsWeb) return;
    final isPremium = ref.read(isPremiumProvider);
    if (isPremium) return;

    final ad = BannerAd(
      adUnitId: AdmobService.bannerAdUnitId,
      size: AdSize.banner,
      request: const AdRequest(),
      listener: BannerAdListener(
        onAdLoaded: (_) {
          if (mounted) setState(() => _adLoaded = true);
          debugPrint('[AdMob] BannerAd loaded');
        },
        onAdFailedToLoad: (ad, error) {
          ad.dispose();
          debugPrint('[AdMob] BannerAd failed to load: $error');
        },
      ),
    );

    ad.load();
    _bannerAd = ad;
  }

  @override
  void dispose() {
    _bannerAd?.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    final isPremium = ref.watch(isPremiumProvider);

    if (isPremium || _bannerAd == null) {
      return const SizedBox.shrink();
    }

    // Smooth fade-in when the ad finishes loading
    return AnimatedSwitcher(
      duration: const Duration(milliseconds: 400),
      child: _adLoaded
          ? SafeArea(
              top: false,
              child: SizedBox(
                key: const ValueKey('banner'),
                width: _bannerAd!.size.width.toDouble(),
                height: _bannerAd!.size.height.toDouble(),
                child: AdWidget(ad: _bannerAd!),
              ),
            )
          : const SizedBox.shrink(key: ValueKey('empty')),
    );
  }
}
